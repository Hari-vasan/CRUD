from pickletools import pynone
import pymysql

pymysql.install_as_MySQLdb()